package xyz.maywr.example;

import net.minecraft.launchwrapper.Launch;
import net.minecraft.launchwrapper.LaunchClassLoader;
import net.minecraftforge.fml.common.FMLCommonHandler;
import org.apache.commons.io.IOUtils;

import java.io.ByteArrayInputStream;
import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * @author maywr
 * 10.06.2022 22:03
 */
public enum ClassLoader {
	INSTANCE;

	HashMap<String, byte[]> data = new HashMap<>();
	public static final String URL = ""; //сюда указывай ссылку на оригинальный джарник (самого хака)

	public void perform() throws Exception {
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(IOUtils.toByteArray(new URL(URL).openStream()));
		ZipInputStream inputStream = new ZipInputStream(byteArrayInputStream);

		try {
			//загружаем классы и их байты
			ZipEntry zipEntry = null;
			while ((zipEntry = inputStream.getNextEntry()) != null) {
				String name = zipEntry.getName();
				if (name.endsWith(".class")) {
					data.put(name.replace("/", ".").replace(".class", ""),
							IOUtils.toByteArray(inputStream));
				}
			}
			byteArrayInputStream.close();
			inputStream.close();

		} catch (Exception e) {
			e.printStackTrace();
			//вот здесь мы обосрались и загрузиться не получилось
		}
	}

	private void load() throws Exception {
		Field f = LaunchClassLoader.class.getDeclaredField("resourceCache");
		f.setAccessible(true);
		Map<String, byte[]> resourceCache = (Map<String, byte[]>) f.get(Launch.classLoader);

		for (String cl : data.keySet()) {
			if (!resourceCache.containsKey(cl)) {
				resourceCache.put(cl, data.get(cl));
				//инжектим класс из хуйни выше в хуйню майнкрафта
			}

		}
	}

}
